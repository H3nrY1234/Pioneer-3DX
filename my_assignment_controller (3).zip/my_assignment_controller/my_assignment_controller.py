from controller import Supervisor
import pioneer_clnav as pn
import pioneer_simpleproxsensors as psps
import occupancy_grid as ogrid
import math
import pose

# ==================================================================================
# Main Methods 
# ==================================================================================

def run_robot(robot):
    # Get the time step of the current world
    timestep = int(robot.getBasicTimeStep())
    
    movement_counter=0
    speed=6
    
    ts = robot.getDevice("touch sensor")
    ts.enable(timestep)
    
    left_motor = robot.getDevice('left wheel')
    right_motor = robot.getDevice('right wheel')
    left_motor.setPosition(float('inf'))
    right_motor.setPosition(float('inf'))
    
    left_motor.setVelocity(0.0);
    right_motor.setVelocity(0.0);  

    # ---------------------------------------------------------------------------
    # Initialize other classes such as the proximity and occupancy grid classes
    # ---------------------------------------------------------------------------

    pps = psps.PioneerSimpleProxSensors(robot)
    nav = pn.PioneerCLNav(robot, pps)

    # 2nd argument determines how many cells per meter of the arena
    # Use 10 for testing navigation, but 20 for high-quality map (slower)
    occupancy_grid = ogrid.OccupancyGrid(robot, 10, "display", nav.get_real_pose(), pps)

    # ---------------------------------------------------------------------------
    # Initialize exploration waypoints
    # Define systematic exploration waypoints or patterns
    waypoints = [
        pose.Pose(-4.5, -4.5, 0),
        pose.Pose(4, -4, 0),
        pose.Pose(3.5, 2, 0),
        pose.Pose(4.5, 4.5, 0),
        pose.Pose(0, 2.5, 0),
        pose.Pose(0, 0, 0),
        pose.Pose(-3.5, -3.5, 0),
        pose.Pose(-3.5,3, 0),
        pose.Pose(2,4.5, 0),
        pose.Pose(1.5,-1.5, 0)
        
    ]

    current_goal_index = 0
    nav.set_goal(waypoints[current_goal_index])

    # ---------------------------------------------------------------------------
    # Main loop
    while robot.step(timestep) != -1:  
        v = ts.getValue()
        if (v > 0):
            movement_counter = 31
            
        # We use the movement_counter to manage the movements
        # of the robot. When the value is 0 we move straight,
        # then when there is another value this means that we
        # are avoiding an obstacle. For avoiding we first move
        # backward for some cycles and then we turn on ourself.
       
        if (movement_counter == 0):
            left_speed = speed
            right_speed = speed
        elif (movement_counter >= 20):
            left_speed = -speed/2
            right_speed = -speed/2
            movement_counter -= 1
        else:
            left_speed = -speed / 2
            right_speed = speed
            movement_counter -= 1
        left_motor.setVelocity(left_speed)
        right_motor.setVelocity(right_speed)

        # Manage navigation and goal switching
        if nav.update():
            print(f"Reached waypoint {current_goal_index}: {waypoints[current_goal_index]}")
            current_goal_index += 1
            if current_goal_index < len(waypoints):
                nav.set_goal(waypoints[current_goal_index])
                print(f"New goal set: {waypoints[current_goal_index]}")
            else:
                print("Exploration complete!")
                break

        # Debug the robot's real pose
        real_pose = nav.get_real_pose()
        print(f"Robot position: x={real_pose.x:.2f}, y={real_pose.y:.2f}, theta={real_pose.theta:.2f}")

        # Update the occupancy grid
        occupancy_grid.map(real_pose)

        # Visualize the occupancy grid
        occupancy_grid.paint()

    # Ensure motors stop at the end
    nav.update()

    # Cleanup code if needed
    print("Robot exploration finished.")

if __name__ == "__main__":
    # ---------------------------------------------------------------------------
    # Create the Supervised Robot instance
    # ---------------------------------------------------------------------------
    my_robot = Supervisor()
    run_robot(my_robot)