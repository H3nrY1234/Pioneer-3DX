import sys
import math
import pose
import pioneer_simpleproxsensors as psps

class OccupancyGrid:
    """ A custom class to model an occupancy grid with optional display """

    # Display constants
    DARKGRAY = 0x3C3C3C
    GRAY = 0xABABAB
    BLACK = 0x000000
    WHITE = 0xFFFFFF

    # Fixed log odds values
    lprior = math.log(0.5 / (1 - 0.5))
    HALFALPHA = 0.02  # Thickness of any wall found
    HALFBETA = math.pi / 36.0  # Sensor cone opening angle

    def __init__(self, robot, grid_scale, display_name, robot_pose, prox_sensors):
        self.robot = robot
        self.robot_pose = robot_pose
        self.prox_sensors = prox_sensors
        self.radius = self.prox_sensors.get_radius()

        self.arena = robot.getFromDef("ARENA")
        if self.arena is None:
            print("COMP329 >>> Please define the DEF parameter of the RectangleArena as ARENA in the scene tree. <<<", file=sys.stderr)
            return

        floorSize_field = self.arena.getField("floorSize")
        floorSize = floorSize_field.getSFVec2f()
        self.arena_width = floorSize[0]
        self.arena_height = floorSize[1]

        self.num_row_cells = int(grid_scale * self.arena_width)
        self.num_col_cells = int(grid_scale * self.arena_height)
        print(f"Building an Occupancy Grid Map of size {self.num_row_cells} x {self.num_col_cells}")

        self.grid = [self.lprior] * (self.num_row_cells * self.num_col_cells)

        self.display = robot.getDevice(display_name)
        if self.display is not None:
            self.device_width = self.display.getWidth()
            self.device_height = self.display.getHeight()
            wsf = self.device_width / self.arena_width
            hsf = self.device_height / self.arena_height
            self.scalefactor = min(wsf, hsf)
            self.cell_width = int(self.device_width / self.num_row_cells)
            self.cell_height = int(self.device_height / self.num_col_cells)
        else:
            self.device_width = 0
            self.device_height = 0
            self.scalefactor = 0.0

    def get_num_row_cells(self):
        return self.num_row_cells

    def get_num_col_cells(self):
        return self.num_col_cells

    def get_grid_size(self):
        return len(self.grid)

    def get_cell_probability(self, i):
        return self.cell_probability(self.grid[i])

    def get_cell_probability_at_pose(self, p):
        return self.cell_probability(self.grid[i])

    def scale(self, l):
        return int(l * self.scalefactor)

    def mapx(self, x):
        return int((self.device_width / 2.0) + self.scale(x))

    def mapy(self, y):
        return int((self.device_height / 2.0) - self.scale(y))

    def set_pose(self, p):
        self.robot_pose.set_pose_position(p)

    def cell_probability(self, lodds):
        try:
            exp = math.exp(lodds)
        except:
            exp = math.inf
        return 1 - (1 / (1 + exp))

    def map(self, p):
        if self.arena is None:
            print("COMP329 >>> Please define the DEF parameter of the RectangleArena as ARENA in the scene tree. <<<", file=sys.stderr)
            return

        x_orig_offset = self.arena_width / 2
        y_orig_offset = self.arena_height / 2
        x_inc = self.arena_width / self.num_row_cells
        y_inc = self.arena_height / self.num_col_cells
        x_cell_offset = x_inc / 2
        y_cell_offset = y_inc / 2
        self.robot_pose.set_pose_position(p)

        for i in range(len(self.grid)):
            x = x_inc * int(i % self.num_row_cells) - x_orig_offset + x_cell_offset
            y = -(y_inc * int(i / self.num_row_cells) - y_orig_offset + y_cell_offset)
            self.grid[i] = self.grid[i] + self.inv_sensor_model(self.robot_pose, x, y) - self.lprior

    def inv_sensor_model(self, p, x, y):
            dx = x - p.x
            dy = y - p.y
            r = math.sqrt(dx**2 + dy**2)             # range
            phi = math.atan2(dy, dx) - p.theta       # bearing
            logodds = self.lprior                    # default return value
            
            
            if r <= self.radius:
                return math.log(0.4 / (1 - 0.4))  # Free (robot occupies the cell)
    
            # distance over range
            if r > self.prox_sensors.get_maxRange():
                return logodds
    
            # Loop over all sensors
            for k in range(self.prox_sensors.get_number_of_sensors()):
                sensor_pose = self.prox_sensors.get_relative_sensor_pose(k)
                zk = self.prox_sensors.get_value(k)
    
                sensor_phi = sensor_pose.theta
                relative_phi = phi - sensor_phi
                
                # Skip invalid or out-of-range sensors or outside sensor cone
                if zk is None or zk > 3 or abs(relative_phi)> self.HALFBETA:
                   continue
                
                # Update log odds
                if r > min(self.prox_sensors.get_maxRange(),zk + self.HALFALPHA):
                    logodds = self.lprior
                elif zk < self.prox_sensors.get_maxRange() and abs(r - zk) <= self.HALFALPHA:
                    logodds = math.log(0.7/0.3)  # occupied show black
                elif r <= zk:
                    logodds = math.log(0.3/0.7) # free show white
    
            return logodds

    

    def paint(self):
        if self.arena is None:
            print("COMP329 >>> Please define the DEF parameter of the RectangleArena as ARENA in the scene tree. <<<", file=sys.stderr)
            return

        if self.display is None:
            return

        self.display.setColor(0xF0F0F0)
        self.display.fillRectangle(0, 0, self.device_width, self.device_height)
        self.coverage = 0.0
        for i in range(len(self.grid)):
            p = self.cell_probability(self.grid[i])
            x = self.cell_width * int(i % self.num_row_cells)
            y = self.cell_height * int(i / self.num_row_cells)

            if p < 0.1:
                self.display.setColor(self.WHITE)
            elif p < 0.2:
                self.display.setColor(0xDDDDDD)
            elif p < 0.3:
                self.display.setColor(0xBBBBBB)
            elif p < 0.4:
                self.display.setColor(0x999999)
            elif p > 0.9:
                self.display.setColor(self.BLACK)
            elif p > 0.8:
                self.display.setColor(0x222222)
            elif p > 0.7:
                self.display.setColor(0x444444)
            elif p > 0.6:
                self.display.setColor(0x666666)
            else:
                self.display.setColor(self.GRAY)

            self.display.fillRectangle(x, y, self.cell_width, self.cell_height)

            if p < 0.1 or p > 0.9:
                self.coverage += 1.0

        self.coverage = self.coverage / len(self.grid)

        self.display.setColor(self.GRAY)
        x = 0
        for i in range(self.num_row_cells):
            self.display.drawLine(x, 0, x, self.device_height)
            x += self.cell_width

        y = 0
        for j in range(self.num_row_cells):
            self.display.drawLine(0, y, self.device_height, y)
            y += self.cell_height

        self.display.setColor(self.WHITE)
        self.display.fillOval(self.mapx(self.robot_pose.x),
                              self.mapy(self.robot_pose.y),
                              self.scale(self.radius),
                              self.scale(self.radius))

        self.display.setColor(self.DARKGRAY)
        self.display.drawOval(self.mapx(self.robot_pose.x),
                              self.mapy(self.robot_pose.y),
                              self.scale(self.radius),
                              self.scale(self.radius))
        self.display.drawLine(self.mapx(self.robot_pose.x),
                              self.mapy(self.robot_pose.y),
                              self.mapx(self.robot_pose.x + math.cos(self.robot_pose.theta) * self.radius),
                              self.mapy(self.robot_pose.y + math.sin(self.robot_pose.theta) * self.radius))

        self.display.setColor(0xF0F0F0)
        self.display.fillRectangle(self.device_width - 80, self.device_height - 18, self.device_width - 20, self.device_height)
        self.display.setColor(0x000000)
        self.display.drawRectangle(self.device_width - 80, self.device_height - 18, self.device_width - 20, self.device_height)

        self.display.setFont("Arial", 10, True)
        self.display.drawText(f"{self.coverage * 100:.2f}%", self.device_width - 60, self.device_height - 14)

    def _get_closest_sensor_index(self, prox_sensors, phi):
        min_diff = float('inf')
        closest_index = -1

        for i, sensor_pose in enumerate(prox_sensors.ps_pose):
            angle_diff = abs(self._normalize_angle(phi - sensor_pose.theta))
            if angle_diff < min_diff:
                min_diff = angle_diff
                closest_index = i

        return closest_index


